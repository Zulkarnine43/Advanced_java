
import java.sql.SQLException;


public class db {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
     test connect=new test();
        connect.getdata();
    }
    
}
