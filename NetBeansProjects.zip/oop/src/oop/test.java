/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author DELL
 */
public class test {
    
    String name,home;
    int id,phone;
         for(i=0;i<=n;i++){
         for(j=0;j<i;j++){
             System.out.println(i);
         }
         System.out.println("\n");
    }
    
}
