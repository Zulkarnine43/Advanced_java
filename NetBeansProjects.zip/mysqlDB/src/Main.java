
public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        BDconnect connect=new BDconnect();
        connect.getData();
    }
    
}
