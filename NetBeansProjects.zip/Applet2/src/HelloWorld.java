import java.applet.Applet; 
import java.awt.Graphics; 
/**
 *
 * @author DELL
 */
public class HelloWorld extends Applet {
    @Override
    public void paint(Graphics g)  
    { 
        g.drawString("Hello World", 20, 20); 
    } 
      
}
