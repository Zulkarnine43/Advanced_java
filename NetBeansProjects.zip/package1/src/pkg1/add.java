/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1;

/**
 *
 * @author DELL
 */
public class add {
    
    public void run(){
        int a=15,b=20;
        int sum=a+b;
        System.out.println("Sum is"+sum);
    }
    
}
