package pkg2;
/**
 *
 * @author Zulkar Nine
 */
public class ClassB {
     public void displayB(int batch, float cgpa){
         
          System.out.println("batch is="+batch+"\n");
          System.out.println("cgpa is="+cgpa+"\n");          
}
}
