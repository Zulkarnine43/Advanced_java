/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2;
import pkg1.*;
public class main {
    public static void main(String[] args) {
        add sum=new add();
        sum.run();
    }
}
