class b extends Thread{
   public void run(){
        for(int i=0;i<=5;i++){
         
    System.out.println("thread start b="+i);
}
        System.out.println("thread b end ");
   }
}



class c extends Thread{
   public void run(){
        for(int i=0;i<=5;i++){
               if(i==1)
            try{
                sleep(1);
            }catch(Exception e){
                
            }
    System.out.println("thread start c="+i);
}
        System.out.println("thread c end ");
   }
}
public class sleepThread {
    public static void main(String[] args) {
        b threadA=new b();
        c threadB=new c();
        threadA.start();
        threadB.start();
    }
}
