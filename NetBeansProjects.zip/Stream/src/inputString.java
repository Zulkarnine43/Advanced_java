//import java.io.*;
//public class inputString {
//public static void main(String[] args) throws FileNotFoundException, IOException {	FileInputStream infile = null;
//	int b;
//	try{
//		infile = new FileInputStream("C:\\Users\\DELL\\Documents\\file\\file.txt");
//		while((b= infile.read())!=-1)
//		{
//			System.out.print(b);
//		}
//		infile.close();
//	}
//	catch(IOException ioe){System.out.println(ioe);
//}
//    }
//}
