import java.awt.*;
import java.applet.*;


public class WelcomeApplet extends Applet {
	
	public void init() {
	}

	public void paint(Graphics g) {
		g.drawString("Welcome to Java Programming!", 			25, 25 );
	}
}
