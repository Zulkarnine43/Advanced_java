
class GFG2 {
    public static void main(String[] args)
    {

        int[][] salesgirl = { { 310,275,365 },
                              { 210,190, 325},
                              {405,235,240},
                              {260,300,380}};

        for (int i = 0; i < salesgirl.length; i++)
            for (int j = 0; j < salesgirl[0].length; j++)
                System.out.println("salesgirl[" + i + "][" + j + "] = "
                                   + salesgirl[i][j]);
    }
}