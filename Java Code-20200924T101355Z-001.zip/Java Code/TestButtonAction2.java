import java.awt.*;
import java.awt.event.*;
public class TestButtonAction2 {
  public static void main(String[] args){
    Frame f = new Frame("TestButton1");
    f.setSize(200,200);
    f.setLayout(new FlowLayout(FlowLayout.LEFT));

    Button hw = new Button("Hello World!");
    f.add(hw);
	Button ww = new Button(" Welcome World!");
    f.add(ww);


    hw.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	System.exit(0);
      }
    });

    ww.addActionListener(new ActionListener(){
	      public void actionPerformed(ActionEvent e){
		System.exit(0);
	      }
    });

    f.setVisible(true);
  }
}
