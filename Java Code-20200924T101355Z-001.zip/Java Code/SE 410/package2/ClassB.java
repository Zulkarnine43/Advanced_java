package package2;

public class ClassB
{
protected int m=10;
public void displayB()
{
System.out.println("Class B");
System.out.println("m = " + m);
}
}