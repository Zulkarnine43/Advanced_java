import package1.ClassA;

class PackageTest1
	{
		public static void main(String args[])
		{
			ClassA objectA=new ClassA();
			objectA.displayA();
			objectA.sum(10,20);
		}
	}
