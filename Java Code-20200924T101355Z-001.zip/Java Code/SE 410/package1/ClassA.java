package package1;
public class ClassA
{
public void displayA()
{
System.out.println("Class A");
}
public void sum(int x, int y)
{
int a,b,c;
a=x;
b=y;
c=a+b;
System.out.println("Sum= "+c);
}
}