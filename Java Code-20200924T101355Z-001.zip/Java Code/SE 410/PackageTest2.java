import package1.ClassA;
import package2.*;

class PackageTest2
{
public static void main(String args[])
{
ClassA objectA=new ClassA();
ClassB objectB=new ClassB();
objectA.displayA();
objectB.displayB();
}
}