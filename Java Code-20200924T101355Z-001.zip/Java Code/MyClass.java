import java.util.Scanner; // import the Scanner class

class MyClass {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);
    String userName, userID;

    // Enter username and press Enter
    System.out.println("Enter username");
    userName = myObj.nextLine();

    System.out.println("Enter userID");
    userID = myObj.nextLine();

    System.out.println("Student Name: " + userName);
    System.out.println("Student ID: " + userID);
  }
}
